<?php
/**
 *
 * @Author: 会飞的鱼
 * @Date: 2024/5/14 0014
 * @Time: 19:59
 * @Blog：https://houz.cn/
 * @Description: 会飞的鱼作品,禁止修改版权违者必究。
 */


namespace app\model;


use think\Model;

class Cdks extends Model
{

}