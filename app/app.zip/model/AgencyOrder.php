<?php
/**
 *
 * @Author: 会飞的鱼
 * @Date: 2024/4/1 0001
 * @Time: 20:00
 * @Blog：https://houz.cn/
 * @Description: 会飞的鱼作品,禁止修改版权违者必究。
 */
declare (strict_types=1);
namespace app\model;

use think\Model;
class AgencyOrder extends Model
{

}